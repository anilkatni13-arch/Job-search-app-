export const initialLeads = [
  {
    id: 1,
    name: 'Rohit Sharma',
    phone: '9876543210',
    project: 'Star City Phase 1',
    unitType: '2BHK',
    status: 'New',
    source: 'Facebook Ads',
    followUpDate: '2026-07-08',
    notes: 'Interested in ground floor unit',
  },
  {
    id: 2,
    name: 'Priya Verma',
    phone: '9123456780',
    project: 'Star City Phase 2',
    unitType: '3BHK',
    status: 'Contacted',
    source: 'Google My Business',
    followUpDate: '2026-07-06',
    notes: 'Asked for site visit this weekend',
  },
  {
    id: 3,
    name: 'Amit Tiwari',
    phone: '9988776655',
    project: 'Star City Phase 1',
    unitType: '2BHK',
    status: 'Site Visit Scheduled',
    source: 'Referral',
    followUpDate: '2026-07-05',
    notes: 'Coming with family on Sunday',
  },
  {
    id: 4,
    name: 'Sneha Jain',
    phone: '9871234560',
    project: 'Star City Phase 2',
    unitType: '3BHK',
    status: 'Negotiation',
    source: 'WhatsApp',
    followUpDate: '2026-07-07',
    notes: 'Discussing payment plan',
  },
  {
    id: 5,
    name: 'Vikas Patel',
    phone: '9090909090',
    project: 'Star City Phase 1',
    unitType: '2BHK',
    status: 'Closed Won',
    source: 'Walk-in',
    followUpDate: '',
    notes: 'Booking done, token received',
  },
];

export const unitInventory = {
  'Star City Phase 1': {
    total: 60,
    sold: 22,
    booked: 8,
    available: 30,
  },
  'Star City Phase 2': {
    total: 80,
    sold: 15,
    booked: 10,
    available: 55,
  },
};

export const leadStatuses = [
  'New',
  'Contacted',
  'Site Visit Scheduled',
  'Negotiation',
  'Closed Won',
  'Closed Lost',
];

export const leadSources = [
  'Facebook Ads',
  'Google My Business',
  'Referral',
  'WhatsApp',
  'Walk-in',
  'Website',
];
