import React from 'react';
import { Phone } from 'lucide-react';

const statusColors = {
  New: '#3b82f6',
  Contacted: '#f59e0b',
  'Site Visit Scheduled': '#8b5cf6',
  Negotiation: '#ec4899',
  'Closed Won': '#16a34a',
  'Closed Lost': '#ef4444',
};

function LeadTable({ leads, statuses, onStatusChange }) {
  return (
    <div style={{ background: 'white', borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.08)', overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead>
          <tr style={{ background: '#f1f5f9', textAlign: 'left' }}>
            <th style={thStyle}>Name</th>
            <th style={thStyle}>Phone</th>
            <th style={thStyle}>Project</th>
            <th style={thStyle}>Unit</th>
            <th style={thStyle}>Source</th>
            <th style={thStyle}>Follow-up</th>
            <th style={thStyle}>Status</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <tr key={lead.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
              <td style={tdStyle}>{lead.name}</td>
              <td style={tdStyle}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Phone size={14} color="#64748b" />
                  {lead.phone}
                </div>
              </td>
              <td style={tdStyle}>{lead.project}</td>
              <td style={tdStyle}>{lead.unitType}</td>
              <td style={tdStyle}>{lead.source}</td>
              <td style={tdStyle}>{lead.followUpDate || '-'}</td>
              <td style={tdStyle}>
                <select
                  value={lead.status}
                  onChange={(e) => onStatusChange(lead.id, e.target.value)}
                  style={{
                    padding: '4px 8px',
                    borderRadius: 6,
                    border: `1px solid ${statusColors[lead.status]}`,
                    color: statusColors[lead.status],
                    fontWeight: 600,
                    fontSize: 12,
                    background: `${statusColors[lead.status]}10`,
                  }}
                >
                  {statuses.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const thStyle = { padding: '12px 16px', fontWeight: 600, color: '#475569' };
const tdStyle = { padding: '12px 16px' };

export default LeadTable;
