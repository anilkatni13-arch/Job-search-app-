import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';

function AddLeadModal({ onAdd, onClose, sources }) {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    project: 'Star City Phase 1',
    unitType: '2BHK',
    source: sources[0],
    notes: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.phone) return;
    onAdd({
      ...form,
      id: Date.now(),
      status: 'New',
      followUpDate: '',
    });
    onClose();
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.4)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 50,
      }}
    >
      <div style={{ background: 'white', borderRadius: 14, padding: 24, width: 400 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
          <h3 style={{ fontSize: 18, fontWeight: 700 }}>Add New Lead</h3>
          <X style={{ cursor: 'pointer' }} onClick={onClose} />
        </div>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <input
            placeholder="Full Name"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            style={inputStyle}
            required
          />
          <input
            placeholder="Phone Number"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            style={inputStyle}
            required
          />
          <select
            value={form.project}
            onChange={(e) => setForm({ ...form, project: e.target.value })}
            style={inputStyle}
          >
            <option>Star City Phase 1</option>
            <option>Star City Phase 2</option>
          </select>
          <select
            value={form.unitType}
            onChange={(e) => setForm({ ...form, unitType: e.target.value })}
            style={inputStyle}
          >
            <option>2BHK</option>
            <option>3BHK</option>
          </select>
          <select
            value={form.source}
            onChange={(e) => setForm({ ...form, source: e.target.value })}
            style={inputStyle}
          >
            {sources.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
          <textarea
            placeholder="Notes"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            style={{ ...inputStyle, height: 60 }}
          />
          <button
            type="submit"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 6,
              padding: '10px',
              background: '#2563eb',
              color: 'white',
              border: 'none',
              borderRadius: 8,
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            <Plus size={16} /> Add Lead
          </button>
        </form>
      </div>
    </div>
  );
}

const inputStyle = {
  padding: '10px 12px',
  borderRadius: 8,
  border: '1px solid #cbd5e1',
  fontSize: 14,
};

export default AddLeadModal;
