import React from 'react';
import { Users, PhoneCall, Calendar, TrendingUp } from 'lucide-react';

function StatsCards({ leads }) {
  const total = leads.length;
  const newLeads = leads.filter((l) => l.status === 'New').length;
  const siteVisits = leads.filter((l) => l.status === 'Site Visit Scheduled').length;
  const closedWon = leads.filter((l) => l.status === 'Closed Won').length;

  const cards = [
    { label: 'Total Leads', value: total, icon: Users, color: '#2563eb' },
    { label: 'New Leads', value: newLeads, icon: PhoneCall, color: '#f59e0b' },
    { label: 'Site Visits', value: siteVisits, icon: Calendar, color: '#8b5cf6' },
    { label: 'Closed Won', value: closedWon, icon: TrendingUp, color: '#16a34a' },
  ];

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
      {cards.map((card) => (
        <div
          key={card.label}
          style={{
            background: 'white',
            borderRadius: 12,
            padding: 18,
            boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
            display: 'flex',
            alignItems: 'center',
            gap: 14,
          }}
        >
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 10,
              background: `${card.color}20`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <card.icon size={22} color={card.color} />
          </div>
          <div>
            <div style={{ fontSize: 22, fontWeight: 700 }}>{card.value}</div>
            <div style={{ fontSize: 12, color: '#64748b' }}>{card.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default StatsCards;
