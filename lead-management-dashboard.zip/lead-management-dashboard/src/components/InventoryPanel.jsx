import React from 'react';
import { Home } from 'lucide-react';

function InventoryPanel({ inventory }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>
      {Object.entries(inventory).map(([project, data]) => (
        <div
          key={project}
          style={{
            background: 'white',
            borderRadius: 12,
            padding: 20,
            boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <Home size={20} color="#2563eb" />
            <h3 style={{ fontSize: 16, fontWeight: 600 }}>{project}</h3>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
            <div>
              <div style={{ color: '#64748b' }}>Total</div>
              <div style={{ fontWeight: 700, fontSize: 18 }}>{data.total}</div>
            </div>
            <div>
              <div style={{ color: '#64748b' }}>Sold</div>
              <div style={{ fontWeight: 700, fontSize: 18, color: '#16a34a' }}>{data.sold}</div>
            </div>
            <div>
              <div style={{ color: '#64748b' }}>Booked</div>
              <div style={{ fontWeight: 700, fontSize: 18, color: '#f59e0b' }}>{data.booked}</div>
            </div>
            <div>
              <div style={{ color: '#64748b' }}>Available</div>
              <div style={{ fontWeight: 700, fontSize: 18, color: '#2563eb' }}>{data.available}</div>
            </div>
          </div>
          <div style={{ marginTop: 12, height: 8, background: '#e2e8f0', borderRadius: 4, overflow: 'hidden' }}>
            <div
              style={{
                width: `${(data.sold / data.total) * 100}%`,
                height: '100%',
                background: '#16a34a',
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

export default InventoryPanel;
