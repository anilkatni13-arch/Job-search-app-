import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../auth/domain/providers/auth_provider.dart';
import '../../../jobs/domain/providers/job_provider.dart';
import '../../../tracker/data/models/application_model.dart';
import '../../../tracker/domain/providers/tracker_provider.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateProvider).asData?.value;
    final applications = ref.watch(applicationsProvider).asData?.value ?? [];
    final savedJobs = ref.watch(savedJobsProvider).asData?.value ?? [];

    final interviewCount =
        applications.where((a) => a.status == ApplicationStatus.interviewing).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => context.push(AppRoutes.profile),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(applicationsProvider);
          ref.invalidate(savedJobsProvider);
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              'Welcome back${user?.name.isNotEmpty == true ? ', ${user!.name.split(' ').first}' : ''} 👋',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.4,
              children: [
                _StatCard(
                  icon: Icons.send_outlined,
                  label: 'Total Applications',
                  value: '${applications.length}',
                  color: Colors.blue,
                ),
                _StatCard(
                  icon: Icons.groups_outlined,
                  label: 'Interviews',
                  value: '$interviewCount',
                  color: Colors.orange,
                ),
                _StatCard(
                  icon: Icons.bookmark_outline,
                  label: 'Saved Jobs',
                  value: '${savedJobs.length}',
                  color: Colors.purple,
                ),
                const _StatCard(
                  icon: Icons.auto_awesome,
                  label: 'AI Match Score',
                  value: '—',
                  color: Colors.green,
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Recent Jobs', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                TextButton(
                  onPressed: () => context.push(AppRoutes.jobSearch),
                  child: const Text('See all'),
                ),
              ],
            ),
            Consumer(builder: (context, ref, _) {
              final jobsAsync = ref.watch(jobSearchResultsProvider);
              return jobsAsync.when(
                loading: () => const Padding(
                  padding: EdgeInsets.all(16),
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (e, _) => const SizedBox(),
                data: (jobs) => Column(
                  children: jobs.take(5).map((job) => Card(
                        child: ListTile(
                          title: Text(job.title),
                          subtitle: Text('${job.company} • ${job.location}'),
                          onTap: () => context.push(AppRoutes.jobDetails, extra: job.id),
                        ),
                      )).toList(),
                ),
              );
            }),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (i) {
          switch (i) {
            case 0:
              break;
            case 1:
              context.push(AppRoutes.jobSearch);
              break;
            case 2:
              context.push(AppRoutes.resumeBuilder);
              break;
            case 3:
              context.push(AppRoutes.tracker);
              break;
            case 4:
              context.push(AppRoutes.profile);
              break;
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Jobs'),
          NavigationDestination(icon: Icon(Icons.description_outlined), label: 'Resume'),
          NavigationDestination(icon: Icon(Icons.track_changes_outlined), label: 'Tracker'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: color),
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
