import '../../../../shared/models/user_model.dart';

abstract class ProfileRepository {
  Future<void> updateProfile(UserModel user);
  Future<void> uploadProfilePhoto(String userId, String filePath);
}
