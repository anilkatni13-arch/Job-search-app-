import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/custom_button.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../../auth/domain/providers/auth_provider.dart';
import '../../domain/providers/job_provider.dart';

class JobDetailsScreen extends ConsumerWidget {
  final String jobId;
  const JobDetailsScreen({super.key, required this.jobId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final jobAsync = ref.watch(jobDetailsProvider(jobId));
    final user = ref.watch(authStateProvider).asData?.value;

    return Scaffold(
      appBar: AppBar(title: const Text('Job Details')),
      body: jobAsync.when(
        loading: () => const LoadingIndicator(),
        error: (e, _) => ErrorView(message: e.toString()),
        data: (job) => Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            children: [
              Text(job.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('${job.company} • ${job.location}',
                  style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: job.skills.map((s) => Chip(label: Text(s))).toList(),
              ),
              const SizedBox(height: 20),
              Text(job.description),
              const SizedBox(height: 24),
              CustomButton(
                label: 'Save Job',
                outlined: true,
                onPressed: user == null
                    ? null
                    : () => ref.read(jobRepositoryProvider).saveJob(user.uid, job),
              ),
              const SizedBox(height: 12),
              CustomButton(label: 'Apply Now', onPressed: () {
                // TODO: launch job.applyUrl via url_launcher, log to tracker
              }),
            ],
          ),
        ),
      ),
    );
  }
}
