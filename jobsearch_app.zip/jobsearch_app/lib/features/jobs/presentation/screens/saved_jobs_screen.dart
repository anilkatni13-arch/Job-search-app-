import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../domain/providers/job_provider.dart';

class SavedJobsScreen extends ConsumerWidget {
  const SavedJobsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final savedAsync = ref.watch(savedJobsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Saved Jobs')),
      body: savedAsync.when(
        loading: () => const LoadingIndicator(),
        error: (e, _) => ErrorView(message: e.toString()),
        data: (jobs) {
          if (jobs.isEmpty) {
            return const Center(child: Text('No saved jobs yet.'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: jobs.length,
            itemBuilder: (context, i) {
              final job = jobs[i];
              return Card(
                child: ListTile(
                  title: Text(job.title),
                  subtitle: Text('${job.company} • ${job.location}'),
                  onTap: () => context.push(AppRoutes.jobDetails, extra: job.id),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
