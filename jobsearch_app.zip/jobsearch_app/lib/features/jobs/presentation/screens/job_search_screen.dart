import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/router/app_router.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../domain/providers/job_provider.dart';

class JobSearchScreen extends ConsumerStatefulWidget {
  const JobSearchScreen({super.key});

  @override
  ConsumerState<JobSearchScreen> createState() => _JobSearchScreenState();
}

class _JobSearchScreenState extends ConsumerState<JobSearchScreen> {
  final _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final filters = ref.watch(jobFiltersProvider);
    final jobsAsync = ref.watch(jobSearchResultsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Job Search'),
        actions: [
          IconButton(
            icon: const Icon(Icons.bookmark_outline),
            onPressed: () => context.push(AppRoutes.savedJobs),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search job title, skill, company...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.tune),
                  onPressed: () {}, // TODO: open filter sheet
                ),
              ),
              onSubmitted: (v) => ref
                  .read(jobFiltersProvider.notifier)
                  .update((s) => s.copyWith(query: v)),
            ),
          ),
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _CountryChip(
                  label: 'All',
                  selected: filters.country == null,
                  onTap: () => ref
                      .read(jobFiltersProvider.notifier)
                      .update((s) => s.copyWith(country: null)),
                ),
                ...AppConstants.supportedCountries.map(
                  (c) => _CountryChip(
                    label: c,
                    selected: filters.country == c,
                    onTap: () => ref
                        .read(jobFiltersProvider.notifier)
                        .update((s) => s.copyWith(country: c)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: jobsAsync.when(
              loading: () => const LoadingIndicator(message: 'Finding best matches...'),
              error: (e, _) => ErrorView(
                message: e.toString(),
                onRetry: () => ref.invalidate(jobSearchResultsProvider),
              ),
              data: (jobs) {
                if (jobs.isEmpty) {
                  return const Center(child: Text('No jobs found. Try another search.'));
                }
                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: jobs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, i) {
                    final job = jobs[i];
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(12),
                        title: Text(job.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text('${job.company} • ${job.location}'),
                        ),
                        trailing: job.aiMatchScore != null
                            ? Chip(label: Text('${job.aiMatchScore!.toInt()}% match'))
                            : null,
                        onTap: () => context.push(AppRoutes.jobDetails, extra: job.id),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _CountryChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _CountryChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => onTap()),
    );
  }
}
