import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/domain/providers/auth_provider.dart';
import '../../data/models/job_model.dart';
import '../../data/repositories/job_repository_impl.dart';
import '../repositories/job_repository.dart';

final jobRepositoryProvider = Provider<JobRepository>((ref) => JobRepositoryImpl());

class JobSearchFilters {
  final String query;
  final String? country; // null = all, else USA/UK/Canada
  final bool remoteOnly;

  const JobSearchFilters({this.query = '', this.country, this.remoteOnly = true});

  JobSearchFilters copyWith({String? query, String? country, bool? remoteOnly}) {
    return JobSearchFilters(
      query: query ?? this.query,
      country: country ?? this.country,
      remoteOnly: remoteOnly ?? this.remoteOnly,
    );
  }
}

final jobFiltersProvider = StateProvider<JobSearchFilters>((ref) => const JobSearchFilters());

final jobSearchResultsProvider = FutureProvider.autoDispose<List<JobModel>>((ref) async {
  final filters = ref.watch(jobFiltersProvider);
  final repo = ref.watch(jobRepositoryProvider);
  return repo.searchJobs(
    query: filters.query,
    country: filters.country,
    remoteOnly: filters.remoteOnly,
  );
});

final jobDetailsProvider =
    FutureProvider.autoDispose.family<JobModel, String>((ref, jobId) async {
  return ref.watch(jobRepositoryProvider).getJobDetails(jobId);
});

final savedJobsProvider = StreamProvider.autoDispose<List<JobModel>>((ref) {
  final user = ref.watch(authStateProvider).asData?.value;
  if (user == null) return const Stream.empty();
  return ref.watch(jobRepositoryProvider).savedJobs(user.uid);
});
