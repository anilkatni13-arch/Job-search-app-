import '../../data/models/job_model.dart';

abstract class JobRepository {
  Future<List<JobModel>> searchJobs({
    String? query,
    String? country,
    bool remoteOnly = false,
  });
  Future<JobModel> getJobDetails(String jobId);

  Future<void> saveJob(String userId, JobModel job);
  Future<void> unsaveJob(String userId, String jobId);
  Stream<List<JobModel>> savedJobs(String userId);
}
