import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../domain/repositories/job_repository.dart';
import '../models/job_model.dart';

/// Live job listings come from the FastAPI backend (which in turn
/// aggregates/ranks jobs, optionally using OpenAI for AI match scoring).
/// Saved jobs are stored per-user in Firestore.
class JobRepositoryImpl implements JobRepository {
  final ApiClient _api;
  final FirebaseFirestore _firestore;

  JobRepositoryImpl({ApiClient? api, FirebaseFirestore? firestore})
      : _api = api ?? ApiClient(),
        _firestore = firestore ?? FirebaseFirestore.instance;

  @override
  Future<List<JobModel>> searchJobs({
    String? query,
    String? country,
    bool remoteOnly = false,
  }) async {
    final res = await _api.get(ApiEndpoints.jobSearch, query: {
      if (query != null && query.isNotEmpty) 'q': query,
      if (country != null) 'country': country,
      'remote': remoteOnly,
    });
    final list = (res.data['jobs'] as List? ?? []);
    return list.map((e) => JobModel.fromJson(e)).toList();
  }

  @override
  Future<JobModel> getJobDetails(String jobId) async {
    final res = await _api.get('${ApiEndpoints.jobDetails}/$jobId');
    return JobModel.fromJson(res.data);
  }

  @override
  Future<void> saveJob(String userId, JobModel job) async {
    await _firestore
        .collection(AppConstants.usersCollection)
        .doc(userId)
        .collection(AppConstants.savedJobsCollection)
        .doc(job.id)
        .set(job.toJson());
  }

  @override
  Future<void> unsaveJob(String userId, String jobId) async {
    await _firestore
        .collection(AppConstants.usersCollection)
        .doc(userId)
        .collection(AppConstants.savedJobsCollection)
        .doc(jobId)
        .delete();
  }

  @override
  Stream<List<JobModel>> savedJobs(String userId) {
    return _firestore
        .collection(AppConstants.usersCollection)
        .doc(userId)
        .collection(AppConstants.savedJobsCollection)
        .orderBy('postedAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => JobModel.fromJson(d.data())).toList());
  }
}
