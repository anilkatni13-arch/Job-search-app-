class JobModel {
  final String id;
  final String title;
  final String company;
  final String location; // e.g. "Remote - USA"
  final String country; // USA / UK / Canada / India / etc.
  final bool isRemote;
  final String description;
  final List<String> skills;
  final String? salaryRange;
  final String applyUrl;
  final DateTime postedAt;
  final double? aiMatchScore; // 0-100, computed by backend against user's resume

  const JobModel({
    required this.id,
    required this.title,
    required this.company,
    required this.location,
    required this.country,
    required this.isRemote,
    required this.description,
    required this.skills,
    this.salaryRange,
    required this.applyUrl,
    required this.postedAt,
    this.aiMatchScore,
  });

  factory JobModel.fromJson(Map<String, dynamic> json) {
    return JobModel(
      id: json['id'].toString(),
      title: json['title'] ?? '',
      company: json['company'] ?? '',
      location: json['location'] ?? '',
      country: json['country'] ?? '',
      isRemote: json['isRemote'] ?? false,
      description: json['description'] ?? '',
      skills: List<String>.from(json['skills'] ?? []),
      salaryRange: json['salaryRange'],
      applyUrl: json['applyUrl'] ?? '',
      postedAt: json['postedAt'] != null
          ? DateTime.parse(json['postedAt'])
          : DateTime.now(),
      aiMatchScore: (json['aiMatchScore'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'company': company,
      'location': location,
      'country': country,
      'isRemote': isRemote,
      'description': description,
      'skills': skills,
      'salaryRange': salaryRange,
      'applyUrl': applyUrl,
      'postedAt': postedAt.toIso8601String(),
      'aiMatchScore': aiMatchScore,
    };
  }
}
