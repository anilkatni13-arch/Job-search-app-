import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/custom_button.dart';
import '../../../../shared/widgets/custom_textfield.dart';
import '../../../auth/domain/providers/auth_provider.dart';
import '../../data/models/cover_letter_model.dart';
import '../../domain/providers/cover_letter_provider.dart';

class CoverLetterScreen extends ConsumerStatefulWidget {
  const CoverLetterScreen({super.key});

  @override
  ConsumerState<CoverLetterScreen> createState() => _CoverLetterScreenState();
}

class _CoverLetterScreenState extends ConsumerState<CoverLetterScreen> {
  final _jobTitle = TextEditingController();
  final _company = TextEditingController();
  final _resumeSummary = TextEditingController();
  String _generated = '';
  bool _loading = false;

  Future<void> _generate() async {
    setState(() => _loading = true);
    try {
      final content = await ref.read(coverLetterRepositoryProvider).generate(
            jobTitle: _jobTitle.text,
            companyName: _company.text,
            resumeSummary: _resumeSummary.text,
          );
      setState(() => _generated = content);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    final user = ref.read(authStateProvider).asData?.value;
    if (user == null || _generated.isEmpty) return;
    final letter = CoverLetterModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      userId: user.uid,
      jobTitle: _jobTitle.text,
      companyName: _company.text,
      content: _generated,
      createdAt: DateTime.now(),
    );
    await ref.read(coverLetterRepositoryProvider).save(letter);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Cover Letter')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            CustomTextField(controller: _jobTitle, label: 'Job Title'),
            const SizedBox(height: 16),
            CustomTextField(controller: _company, label: 'Company Name'),
            const SizedBox(height: 16),
            CustomTextField(
              controller: _resumeSummary,
              label: 'Your resume summary / key skills',
              maxLines: 4,
            ),
            const SizedBox(height: 20),
            CustomButton(
              label: 'Generate Cover Letter',
              icon: Icons.auto_awesome,
              isLoading: _loading,
              onPressed: _generate,
            ),
            if (_generated.isNotEmpty) ...[
              const SizedBox(height: 24),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(_generated),
                ),
              ),
              const SizedBox(height: 12),
              CustomButton(label: 'Save', outlined: true, onPressed: _save),
            ],
          ],
        ),
      ),
    );
  }
}
