import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../domain/repositories/cover_letter_repository.dart';
import '../models/cover_letter_model.dart';

class CoverLetterRepositoryImpl implements CoverLetterRepository {
  final ApiClient _api;
  final FirebaseFirestore _firestore;

  CoverLetterRepositoryImpl({ApiClient? api, FirebaseFirestore? firestore})
      : _api = api ?? ApiClient(),
        _firestore = firestore ?? FirebaseFirestore.instance;

  @override
  Future<String> generate({
    required String jobTitle,
    required String companyName,
    required String resumeSummary,
    String tone = 'professional',
  }) async {
    final res = await _api.post(ApiEndpoints.coverLetterGenerate, data: {
      'jobTitle': jobTitle,
      'companyName': companyName,
      'resumeSummary': resumeSummary,
      'tone': tone,
    });
    return res.data['content'] ?? '';
  }

  @override
  Future<void> save(CoverLetterModel letter) async {
    await _firestore
        .collection(AppConstants.coverLettersCollection)
        .doc(letter.id)
        .set(letter.toJson());
  }

  @override
  Future<List<CoverLetterModel>> history(String userId) async {
    final snap = await _firestore
        .collection(AppConstants.coverLettersCollection)
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .get();
    return snap.docs.map((d) => CoverLetterModel.fromJson(d.data())).toList();
  }
}
