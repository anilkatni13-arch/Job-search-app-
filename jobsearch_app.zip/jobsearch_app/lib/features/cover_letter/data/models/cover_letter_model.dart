class CoverLetterModel {
  final String id;
  final String userId;
  final String jobTitle;
  final String companyName;
  final String content;
  final DateTime createdAt;

  const CoverLetterModel({
    required this.id,
    required this.userId,
    required this.jobTitle,
    required this.companyName,
    required this.content,
    required this.createdAt,
  });

  factory CoverLetterModel.fromJson(Map<String, dynamic> json) => CoverLetterModel(
        id: json['id'] ?? '',
        userId: json['userId'] ?? '',
        jobTitle: json['jobTitle'] ?? '',
        companyName: json['companyName'] ?? '',
        content: json['content'] ?? '',
        createdAt:
            json['createdAt'] != null ? DateTime.parse(json['createdAt']) : DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'jobTitle': jobTitle,
        'companyName': companyName,
        'content': content,
        'createdAt': createdAt.toIso8601String(),
      };
}
