import '../../data/models/cover_letter_model.dart';

abstract class CoverLetterRepository {
  Future<String> generate({
    required String jobTitle,
    required String companyName,
    required String resumeSummary,
    String tone = 'professional',
  });
  Future<void> save(CoverLetterModel letter);
  Future<List<CoverLetterModel>> history(String userId);
}
