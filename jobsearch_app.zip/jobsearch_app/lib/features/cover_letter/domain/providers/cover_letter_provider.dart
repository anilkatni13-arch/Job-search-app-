import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/cover_letter_repository_impl.dart';
import '../repositories/cover_letter_repository.dart';

final coverLetterRepositoryProvider =
    Provider<CoverLetterRepository>((ref) => CoverLetterRepositoryImpl());
