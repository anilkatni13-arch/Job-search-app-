import 'package:firebase_auth/firebase_auth.dart' as fb;
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/error/exceptions.dart';
import '../../../../shared/models/user_model.dart';
import '../../domain/repositories/auth_repository.dart';

class AuthRepositoryImpl implements AuthRepository {
  final fb.FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  AuthRepositoryImpl({fb.FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? fb.FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  @override
  Stream<UserModel?> authStateChanges() {
    return _auth.authStateChanges().asyncMap((fbUser) async {
      if (fbUser == null) return null;
      return _fetchUserDoc(fbUser.uid, fallbackEmail: fbUser.email ?? '');
    });
  }

  @override
  UserModel? get currentUser {
    final fbUser = _auth.currentUser;
    if (fbUser == null) return null;
    return UserModel(
      uid: fbUser.uid,
      email: fbUser.email ?? '',
      name: fbUser.displayName ?? '',
      photoUrl: fbUser.photoURL,
      createdAt: DateTime.now(),
    );
  }

  Future<UserModel> _fetchUserDoc(String uid, {required String fallbackEmail}) async {
    final doc = await _firestore.collection(AppConstants.usersCollection).doc(uid).get();
    if (doc.exists) {
      return UserModel.fromMap(doc.data()!, uid);
    }
    return UserModel(uid: uid, email: fallbackEmail, name: '', createdAt: DateTime.now());
  }

  @override
  Future<UserModel> signIn({required String email, required String password}) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(email: email, password: password);
      return _fetchUserDoc(cred.user!.uid, fallbackEmail: email);
    } on fb.FirebaseAuthException catch (e) {
      throw AuthException(e.message ?? 'Login failed');
    }
  }

  @override
  Future<UserModel> signUp({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      await cred.user!.updateDisplayName(name);

      final userModel = UserModel(
        uid: cred.user!.uid,
        email: email,
        name: name,
        createdAt: DateTime.now(),
      );

      await _firestore
          .collection(AppConstants.usersCollection)
          .doc(cred.user!.uid)
          .set(userModel.toMap());

      return userModel;
    } on fb.FirebaseAuthException catch (e) {
      throw AuthException(e.message ?? 'Sign up failed');
    }
  }

  @override
  Future<void> signOut() => _auth.signOut();

  @override
  Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on fb.FirebaseAuthException catch (e) {
      throw AuthException(e.message ?? 'Could not send reset email');
    }
  }
}
