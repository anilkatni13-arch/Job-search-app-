import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/app_constants.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../domain/repositories/resume_repository.dart';
import '../models/resume_model.dart';

class ResumeRepositoryImpl implements ResumeRepository {
  final FirebaseFirestore _firestore;
  final ApiClient _api;

  ResumeRepositoryImpl({FirebaseFirestore? firestore, ApiClient? api})
      : _firestore = firestore ?? FirebaseFirestore.instance,
        _api = api ?? ApiClient();

  @override
  Future<ResumeModel?> getResume(String userId) async {
    final doc =
        await _firestore.collection(AppConstants.resumesCollection).doc(userId).get();
    if (!doc.exists) return null;
    return ResumeModel.fromJson(doc.data()!);
  }

  @override
  Future<void> saveResume(ResumeModel resume) async {
    await _firestore
        .collection(AppConstants.resumesCollection)
        .doc(resume.userId)
        .set(resume.toJson());
  }

  @override
  Future<String> generateAiSummary({required String title, required List<String> skills}) async {
    final res = await _api.post(ApiEndpoints.resumeGenerate, data: {
      'title': title,
      'skills': skills,
    });
    return res.data['summary'] ?? '';
  }

  @override
  Future<AtsScoreResult> getAtsScore(ResumeModel resume, {String? jobDescription}) async {
    final res = await _api.post(ApiEndpoints.resumeAtsScore, data: {
      'resume': resume.toJson(),
      if (jobDescription != null) 'jobDescription': jobDescription,
    });
    return AtsScoreResult.fromJson(res.data);
  }
}
