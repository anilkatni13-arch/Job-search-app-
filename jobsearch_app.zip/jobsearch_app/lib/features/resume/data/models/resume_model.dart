class ResumeModel {
  final String id;
  final String userId;
  final String fullName;
  final String title; // e.g. "Flutter Developer"
  final String summary;
  final List<String> skills;
  final List<ExperienceEntry> experience;
  final List<EducationEntry> education;
  final String? templateId;
  final DateTime updatedAt;

  const ResumeModel({
    required this.id,
    required this.userId,
    required this.fullName,
    required this.title,
    required this.summary,
    required this.skills,
    required this.experience,
    required this.education,
    this.templateId,
    required this.updatedAt,
  });

  factory ResumeModel.fromJson(Map<String, dynamic> json) => ResumeModel(
        id: json['id'] ?? '',
        userId: json['userId'] ?? '',
        fullName: json['fullName'] ?? '',
        title: json['title'] ?? '',
        summary: json['summary'] ?? '',
        skills: List<String>.from(json['skills'] ?? []),
        experience: (json['experience'] as List? ?? [])
            .map((e) => ExperienceEntry.fromJson(e))
            .toList(),
        education: (json['education'] as List? ?? [])
            .map((e) => EducationEntry.fromJson(e))
            .toList(),
        templateId: json['templateId'],
        updatedAt: json['updatedAt'] != null
            ? DateTime.parse(json['updatedAt'])
            : DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'fullName': fullName,
        'title': title,
        'summary': summary,
        'skills': skills,
        'experience': experience.map((e) => e.toJson()).toList(),
        'education': education.map((e) => e.toJson()).toList(),
        'templateId': templateId,
        'updatedAt': updatedAt.toIso8601String(),
      };
}

class ExperienceEntry {
  final String company;
  final String role;
  final String duration;
  final String description;

  const ExperienceEntry({
    required this.company,
    required this.role,
    required this.duration,
    required this.description,
  });

  factory ExperienceEntry.fromJson(Map<String, dynamic> json) => ExperienceEntry(
        company: json['company'] ?? '',
        role: json['role'] ?? '',
        duration: json['duration'] ?? '',
        description: json['description'] ?? '',
      );

  Map<String, dynamic> toJson() =>
      {'company': company, 'role': role, 'duration': duration, 'description': description};
}

class EducationEntry {
  final String institution;
  final String degree;
  final String year;

  const EducationEntry({required this.institution, required this.degree, required this.year});

  factory EducationEntry.fromJson(Map<String, dynamic> json) => EducationEntry(
        institution: json['institution'] ?? '',
        degree: json['degree'] ?? '',
        year: json['year'] ?? '',
      );

  Map<String, dynamic> toJson() => {'institution': institution, 'degree': degree, 'year': year};
}

class AtsScoreResult {
  final int score; // 0-100
  final List<String> strengths;
  final List<String> improvements;

  const AtsScoreResult({required this.score, required this.strengths, required this.improvements});

  factory AtsScoreResult.fromJson(Map<String, dynamic> json) => AtsScoreResult(
        score: json['score'] ?? 0,
        strengths: List<String>.from(json['strengths'] ?? []),
        improvements: List<String>.from(json['improvements'] ?? []),
      );
}
