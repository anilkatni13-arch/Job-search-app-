import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/domain/providers/auth_provider.dart';
import '../../data/models/resume_model.dart';
import '../../data/repositories/resume_repository_impl.dart';
import '../repositories/resume_repository.dart';

final resumeRepositoryProvider = Provider<ResumeRepository>((ref) => ResumeRepositoryImpl());

final myResumeProvider = FutureProvider.autoDispose<ResumeModel?>((ref) async {
  final user = ref.watch(authStateProvider).asData?.value;
  if (user == null) return null;
  return ref.watch(resumeRepositoryProvider).getResume(user.uid);
});

final atsScoreProvider =
    FutureProvider.autoDispose.family<AtsScoreResult, ResumeModel>((ref, resume) async {
  return ref.watch(resumeRepositoryProvider).getAtsScore(resume);
});
