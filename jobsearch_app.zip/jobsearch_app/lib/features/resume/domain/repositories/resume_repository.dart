import '../../data/models/resume_model.dart';

abstract class ResumeRepository {
  Future<ResumeModel?> getResume(String userId);
  Future<void> saveResume(ResumeModel resume);
  /// Calls backend which uses OpenAI to polish/generate resume summary & bullet points.
  Future<String> generateAiSummary({required String title, required List<String> skills});
  Future<AtsScoreResult> getAtsScore(ResumeModel resume, {String? jobDescription});
}
