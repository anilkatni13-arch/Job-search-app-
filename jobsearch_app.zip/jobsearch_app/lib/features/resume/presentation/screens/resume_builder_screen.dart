import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../shared/widgets/custom_button.dart';
import '../../../../shared/widgets/custom_textfield.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../../auth/domain/providers/auth_provider.dart';
import '../../data/models/resume_model.dart';
import '../../domain/providers/resume_provider.dart';

class ResumeBuilderScreen extends ConsumerStatefulWidget {
  const ResumeBuilderScreen({super.key});

  @override
  ConsumerState<ResumeBuilderScreen> createState() => _ResumeBuilderScreenState();
}

class _ResumeBuilderScreenState extends ConsumerState<ResumeBuilderScreen> {
  final _fullName = TextEditingController();
  final _title = TextEditingController();
  final _summary = TextEditingController();
  final _skills = TextEditingController();
  bool _generating = false;
  bool _saving = false;

  Future<void> _generateWithAi() async {
    setState(() => _generating = true);
    try {
      final skillsList = _skills.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
      final summary = await ref
          .read(resumeRepositoryProvider)
          .generateAiSummary(title: _title.text, skills: skillsList);
      _summary.text = summary;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('AI error: $e')));
      }
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _save() async {
    final user = ref.read(authStateProvider).asData?.value;
    if (user == null) return;
    setState(() => _saving = true);
    final resume = ResumeModel(
      id: user.uid,
      userId: user.uid,
      fullName: _fullName.text,
      title: _title.text,
      summary: _summary.text,
      skills: _skills.text.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList(),
      experience: const [],
      education: const [],
      updatedAt: DateTime.now(),
    );
    await ref.read(resumeRepositoryProvider).saveResume(resume);
    setState(() => _saving = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Resume saved')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final existing = ref.watch(myResumeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Resume Builder'),
        actions: [
          IconButton(
            icon: const Icon(Icons.analytics_outlined),
            tooltip: 'ATS Score',
            onPressed: () => context.push(AppRoutes.atsScore),
          ),
        ],
      ),
      body: existing.when(
        loading: () => const LoadingIndicator(),
        error: (e, _) => Center(child: Text('$e')),
        data: (resume) {
          if (resume != null && _fullName.text.isEmpty) {
            _fullName.text = resume.fullName;
            _title.text = resume.title;
            _summary.text = resume.summary;
            _skills.text = resume.skills.join(', ');
          }
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                CustomTextField(controller: _fullName, label: 'Full Name'),
                const SizedBox(height: 16),
                CustomTextField(controller: _title, label: 'Target Job Title'),
                const SizedBox(height: 16),
                CustomTextField(
                  controller: _skills,
                  label: 'Skills (comma separated)',
                  hint: 'Flutter, Dart, Firebase',
                ),
                const SizedBox(height: 16),
                CustomTextField(controller: _summary, label: 'Summary', maxLines: 5),
                const SizedBox(height: 12),
                CustomButton(
                  label: 'Generate with AI',
                  icon: Icons.auto_awesome,
                  outlined: true,
                  isLoading: _generating,
                  onPressed: _generateWithAi,
                ),
                const SizedBox(height: 24),
                CustomButton(label: 'Save Resume', isLoading: _saving, onPressed: _save),
              ],
            ),
          );
        },
      ),
    );
  }
}
