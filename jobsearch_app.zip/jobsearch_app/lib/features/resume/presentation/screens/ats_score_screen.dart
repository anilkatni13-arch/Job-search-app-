import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../domain/providers/resume_provider.dart';

class AtsScoreScreen extends ConsumerWidget {
  const AtsScoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final resumeAsync = ref.watch(myResumeProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('ATS Resume Score')),
      body: resumeAsync.when(
        loading: () => const LoadingIndicator(),
        error: (e, _) => ErrorView(message: e.toString()),
        data: (resume) {
          if (resume == null) {
            return const Center(child: Text('Build your resume first.'));
          }
          final scoreAsync = ref.watch(atsScoreProvider(resume));
          return scoreAsync.when(
            loading: () => const LoadingIndicator(message: 'Analyzing resume...'),
            error: (e, _) => ErrorView(message: e.toString()),
            data: (result) => Padding(
              padding: const EdgeInsets.all(20),
              child: ListView(
                children: [
                  Center(
                    child: CircleAvatar(
                      radius: 60,
                      child: Text('${result.score}', style: const TextStyle(fontSize: 32)),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text('Strengths', style: TextStyle(fontWeight: FontWeight.bold)),
                  ...result.strengths.map((s) => ListTile(
                        leading: const Icon(Icons.check_circle, color: Colors.green),
                        title: Text(s),
                      )),
                  const SizedBox(height: 12),
                  const Text('Improvements', style: TextStyle(fontWeight: FontWeight.bold)),
                  ...result.improvements.map((s) => ListTile(
                        leading: const Icon(Icons.warning_amber, color: Colors.orange),
                        title: Text(s),
                      )),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
