import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../../core/constants/app_constants.dart';
import '../../domain/repositories/tracker_repository.dart';
import '../models/application_model.dart';

class TrackerRepositoryImpl implements TrackerRepository {
  final FirebaseFirestore _firestore;
  TrackerRepositoryImpl({FirebaseFirestore? firestore})
      : _firestore = firestore ?? FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> _col(String userId) => _firestore
      .collection(AppConstants.usersCollection)
      .doc(userId)
      .collection(AppConstants.applicationsCollection);

  @override
  Stream<List<ApplicationModel>> applicationsFor(String userId) {
    return _col(userId).orderBy('appliedAt', descending: true).snapshots().map(
        (snap) => snap.docs.map((d) => ApplicationModel.fromJson(d.data())).toList());
  }

  @override
  Future<void> addApplication(ApplicationModel application) async {
    await _col(application.userId).doc(application.id).set(application.toJson());
  }

  @override
  Future<void> updateStatus(String userId, String applicationId, ApplicationStatus status) async {
    await _col(userId).doc(applicationId).update({'status': status.name});
  }

  @override
  Future<void> deleteApplication(String userId, String applicationId) async {
    await _col(userId).doc(applicationId).delete();
  }
}
