enum ApplicationStatus { applied, interviewing, offer, rejected, saved }

extension ApplicationStatusX on ApplicationStatus {
  String get label {
    switch (this) {
      case ApplicationStatus.applied:
        return 'Applied';
      case ApplicationStatus.interviewing:
        return 'Interviewing';
      case ApplicationStatus.offer:
        return 'Offer';
      case ApplicationStatus.rejected:
        return 'Rejected';
      case ApplicationStatus.saved:
        return 'Saved';
    }
  }
}

class ApplicationModel {
  final String id;
  final String userId;
  final String jobId;
  final String jobTitle;
  final String company;
  final ApplicationStatus status;
  final DateTime appliedAt;
  final String? notes;

  const ApplicationModel({
    required this.id,
    required this.userId,
    required this.jobId,
    required this.jobTitle,
    required this.company,
    required this.status,
    required this.appliedAt,
    this.notes,
  });

  factory ApplicationModel.fromJson(Map<String, dynamic> json) => ApplicationModel(
        id: json['id'] ?? '',
        userId: json['userId'] ?? '',
        jobId: json['jobId'] ?? '',
        jobTitle: json['jobTitle'] ?? '',
        company: json['company'] ?? '',
        status: ApplicationStatus.values.firstWhere(
          (e) => e.name == json['status'],
          orElse: () => ApplicationStatus.applied,
        ),
        appliedAt:
            json['appliedAt'] != null ? DateTime.parse(json['appliedAt']) : DateTime.now(),
        notes: json['notes'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'userId': userId,
        'jobId': jobId,
        'jobTitle': jobTitle,
        'company': company,
        'status': status.name,
        'appliedAt': appliedAt.toIso8601String(),
        'notes': notes,
      };
}
