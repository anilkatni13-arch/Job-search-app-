import '../../data/models/application_model.dart';

abstract class TrackerRepository {
  Stream<List<ApplicationModel>> applicationsFor(String userId);
  Future<void> addApplication(ApplicationModel application);
  Future<void> updateStatus(String userId, String applicationId, ApplicationStatus status);
  Future<void> deleteApplication(String userId, String applicationId);
}
