import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/domain/providers/auth_provider.dart';
import '../../data/models/application_model.dart';
import '../../data/repositories/tracker_repository_impl.dart';
import '../repositories/tracker_repository.dart';

final trackerRepositoryProvider = Provider<TrackerRepository>((ref) => TrackerRepositoryImpl());

final applicationsProvider = StreamProvider.autoDispose<List<ApplicationModel>>((ref) {
  final user = ref.watch(authStateProvider).asData?.value;
  if (user == null) return const Stream.empty();
  return ref.watch(trackerRepositoryProvider).applicationsFor(user.uid);
});
