import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/loading_indicator.dart';
import '../../../auth/domain/providers/auth_provider.dart';
import '../../data/models/application_model.dart';
import '../../domain/providers/tracker_provider.dart';

class TrackerScreen extends ConsumerWidget {
  const TrackerScreen({super.key});

  Color _statusColor(ApplicationStatus s) {
    switch (s) {
      case ApplicationStatus.applied:
        return Colors.blue;
      case ApplicationStatus.interviewing:
        return Colors.orange;
      case ApplicationStatus.offer:
        return Colors.green;
      case ApplicationStatus.rejected:
        return Colors.red;
      case ApplicationStatus.saved:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appsAsync = ref.watch(applicationsProvider);
    final user = ref.watch(authStateProvider).asData?.value;

    return Scaffold(
      appBar: AppBar(title: const Text('Application Tracker')),
      body: appsAsync.when(
        loading: () => const LoadingIndicator(),
        error: (e, _) => ErrorView(message: e.toString()),
        data: (apps) {
          if (apps.isEmpty) {
            return const Center(child: Text('No applications tracked yet.'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: apps.length,
            itemBuilder: (context, i) {
              final app = apps[i];
              return Card(
                child: ListTile(
                  title: Text(app.jobTitle),
                  subtitle: Text(app.company),
                  trailing: DropdownButton<ApplicationStatus>(
                    value: app.status,
                    underline: const SizedBox(),
                    items: ApplicationStatus.values
                        .map((s) => DropdownMenuItem(
                              value: s,
                              child: Text(
                                s.label,
                                style: TextStyle(color: _statusColor(s)),
                              ),
                            ))
                        .toList(),
                    onChanged: (status) {
                      if (status != null && user != null) {
                        ref
                            .read(trackerRepositoryProvider)
                            .updateStatus(user.uid, app.id, status);
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
