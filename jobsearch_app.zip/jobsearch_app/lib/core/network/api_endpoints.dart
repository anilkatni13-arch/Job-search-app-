class ApiEndpoints {
  ApiEndpoints._();

  // Point this to your FastAPI backend base URL (see config/env.dart).
  static const String jobSearch = '/api/v1/jobs/search';
  static const String jobDetails = '/api/v1/jobs'; // + /{id}
  static const String resumeGenerate = '/api/v1/ai/resume/generate';
  static const String resumeAtsScore = '/api/v1/ai/resume/ats-score';
  static const String coverLetterGenerate = '/api/v1/ai/cover-letter/generate';
  static const String aiJobMatch = '/api/v1/ai/jobs/match-score';
}
