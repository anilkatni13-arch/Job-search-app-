// Fallback hardcoded strings (primary source of truth is
// assets/translations/en.json & hi.json via easy_localization).
class AppStrings {
  AppStrings._();

  static const String genericError = 'Something went wrong. Please try again.';
  static const String noInternet = 'No internet connection.';
  static const String loginRequired = 'Please login to continue.';
}
