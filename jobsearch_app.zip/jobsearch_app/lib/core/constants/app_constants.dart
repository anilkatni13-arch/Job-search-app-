class AppConstants {
  AppConstants._();

  static const String appName = 'AI Job Search';

  // Firestore collections
  static const String usersCollection = 'users';
  static const String jobsCollection = 'jobs';
  static const String savedJobsCollection = 'saved_jobs';
  static const String applicationsCollection = 'applications';
  static const String resumesCollection = 'resumes';
  static const String coverLettersCollection = 'cover_letters';

  // Shared prefs keys
  static const String prefThemeMode = 'pref_theme_mode';
  static const String prefLocale = 'pref_locale';
  static const String prefOnboardingDone = 'pref_onboarding_done';

  // Supported remote job countries
  static const List<String> supportedCountries = ['USA', 'UK', 'Canada'];
}
