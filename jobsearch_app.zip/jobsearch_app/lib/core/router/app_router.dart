import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/domain/providers/auth_provider.dart';
import '../../features/auth/presentation/screens/splash_screen.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/auth/presentation/screens/register_screen.dart';
import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/jobs/presentation/screens/job_search_screen.dart';
import '../../features/jobs/presentation/screens/job_details_screen.dart';
import '../../features/jobs/presentation/screens/saved_jobs_screen.dart';
import '../../features/resume/presentation/screens/resume_builder_screen.dart';
import '../../features/resume/presentation/screens/ats_score_screen.dart';
import '../../features/cover_letter/presentation/screens/cover_letter_screen.dart';
import '../../features/tracker/presentation/screens/tracker_screen.dart';
import '../../features/profile/presentation/screens/profile_screen.dart';
import '../../features/profile/presentation/screens/settings_screen.dart';

class AppRoutes {
  AppRoutes._();
  static const splash = '/';
  static const login = '/login';
  static const register = '/register';
  static const dashboard = '/dashboard';
  static const jobSearch = '/jobs';
  static const jobDetails = '/jobs/details';
  static const savedJobs = '/jobs/saved';
  static const resumeBuilder = '/resume';
  static const atsScore = '/resume/ats-score';
  static const coverLetter = '/cover-letter';
  static const tracker = '/tracker';
  static const profile = '/profile';
  static const settings = '/settings';
}

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: AppRoutes.splash,
    redirect: (context, state) {
      final isLoggedIn = authState.asData?.value != null;
      final loggingIn = state.matchedLocation == AppRoutes.login ||
          state.matchedLocation == AppRoutes.register ||
          state.matchedLocation == AppRoutes.splash;

      if (!isLoggedIn && !loggingIn) return AppRoutes.login;
      if (isLoggedIn && loggingIn && state.matchedLocation != AppRoutes.splash) {
        return AppRoutes.dashboard;
      }
      return null;
    },
    routes: [
      GoRoute(path: AppRoutes.splash, builder: (c, s) => const SplashScreen()),
      GoRoute(path: AppRoutes.login, builder: (c, s) => const LoginScreen()),
      GoRoute(path: AppRoutes.register, builder: (c, s) => const RegisterScreen()),
      GoRoute(path: AppRoutes.dashboard, builder: (c, s) => const DashboardScreen()),
      GoRoute(path: AppRoutes.jobSearch, builder: (c, s) => const JobSearchScreen()),
      GoRoute(
        path: AppRoutes.jobDetails,
        builder: (c, s) => JobDetailsScreen(jobId: s.extra as String? ?? ''),
      ),
      GoRoute(path: AppRoutes.savedJobs, builder: (c, s) => const SavedJobsScreen()),
      GoRoute(path: AppRoutes.resumeBuilder, builder: (c, s) => const ResumeBuilderScreen()),
      GoRoute(path: AppRoutes.atsScore, builder: (c, s) => const AtsScoreScreen()),
      GoRoute(path: AppRoutes.coverLetter, builder: (c, s) => const CoverLetterScreen()),
      GoRoute(path: AppRoutes.tracker, builder: (c, s) => const TrackerScreen()),
      GoRoute(path: AppRoutes.profile, builder: (c, s) => const ProfileScreen()),
      GoRoute(path: AppRoutes.settings, builder: (c, s) => const SettingsScreen()),
    ],
  );
});
