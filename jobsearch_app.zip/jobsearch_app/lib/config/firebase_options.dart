// PLACEHOLDER FILE.
// Run `flutterfire configure` in your project root to auto-generate
// the real firebase_options.dart with your project's platform configs.
// https://firebase.google.com/docs/flutter/setup
//
// import 'package:firebase_core/firebase_core.dart';
//
// class DefaultFirebaseOptions {
//   static FirebaseOptions get currentPlatform { ... }
// }
