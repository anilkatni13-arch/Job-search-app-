import 'package:flutter_dotenv/flutter_dotenv.dart';

/// Reads values from the .env file at project root (see .env.example).
/// Never commit real API keys — .env is gitignored.
class Env {
  Env._();

  static String get apiBaseUrl =>
      dotenv.env['API_BASE_URL'] ?? 'https://api.yourbackend.com';

  static String get openAiProxyKeyName => 'OPENAI_API_KEY'; // kept server-side only!
}
